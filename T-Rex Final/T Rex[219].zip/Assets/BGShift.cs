﻿using UnityEngine;
using System.Collections;

public class BGShift : MonoBehaviour {
	//public Transform campos1;
	//public Renderer v1;
	//public float shift;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		//if (!v1.isVisible) {
			
		//}

	}
	void OnTriggerExit2D(Collider2D collider){
		//Debug.Log ("Invisible");
		//shift= v1.bounds.size.x;
		//transform.position=new Vector2(shift,-0.98f);
		float width = ((BoxCollider2D)collider).size.x;
		Vector3 pos = collider.transform.position;
		pos.x += width * 1.95f;
		if(collider.gameObject.tag=="BG")
		collider.transform.position = pos;

		if (collider.gameObject.tag == "BG2")
			collider.transform.position = pos;
	}
}

